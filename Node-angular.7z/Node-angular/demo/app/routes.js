//var Todo = require('./models/todo');
const fs = require('fs');
var dataPath = 'app/models/data.json';

module.exports = function (app) {

	// api ---------------------------------------------------------------------
	// get all todos
	app.get('/api/todos', function (req, res) {
		let data= fs.readFileSync(dataPath);
		let response= JSON.parse(data);			
		res.json(response);
	});

	// create todo and send back all todos after creation
	app.post('/api/todos', function (req, res) {				
		let data = JSON.parse( fs.readFileSync(dataPath));		
		data.push(JSON.parse( req.body.data));		
		fs.writeFileSync(dataPath,JSON.stringify( data));		
		res.json(data);
	});

	// delete a todo
	app.delete('/api/todos/:todo_id', function (req, res) {
		let id= req.params.todo_id;
		let data = JSON.parse( fs.readFileSync(dataPath));
		if(data.length > id){
			data.splice(id,1);			
		}
		fs.writeFileSync(dataPath,JSON.stringify( data));	
		res.json(data);
	});

	// application -------------------------------------------------------------
	app.get('*', function (req, res) {
		res.sendfile('./public/index.html'); // load the single view file (angular will handle the page changes on the front-end)
	});
};